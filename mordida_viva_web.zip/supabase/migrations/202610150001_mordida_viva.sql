-- Esquema inicial para convertir la demo en una tienda con datos persistentes.
-- Ejecutar en Supabase SQL Editor. No contiene claves ni datos de pago.
create extension if not exists pgcrypto;

create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('customer', 'admin')),
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

create or replace function public.has_role(_user_id uuid, _role text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role = _role
  );
$$;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text not null,
  ingredients text not null,
  price_cop integer not null check (price_cop >= 0),
  category text not null check (category in ('Fruta', 'Crujientes', 'Energía')),
  image_path text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  order_number text unique not null,
  customer_name text not null,
  customer_email text not null,
  delivery_address text not null,
  city text not null default 'Bogotá',
  status text not null default 'Recibido'
    check (status in ('Recibido', 'En preparación', 'En camino', 'Entregado', 'Cancelado')),
  subtotal_cop integer not null check (subtotal_cop >= 0),
  shipping_cop integer not null default 0 check (shipping_cop >= 0),
  total_cop integer not null check (total_cop >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  unit_price_cop integer not null check (unit_price_cop >= 0),
  quantity integer not null check (quantity > 0),
  line_total_cop integer not null check (line_total_cop >= 0)
);

alter table public.user_roles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

create policy "Customers can read their own roles"
on public.user_roles for select to authenticated
using (user_id = auth.uid());

create policy "Public can read available products"
on public.products for select to anon, authenticated
using (is_available = true);

create policy "Admins can manage products"
on public.products for all to authenticated
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

create policy "Customers can read their own orders"
on public.orders for select to authenticated
using (user_id = auth.uid());

create policy "Customers can create their own orders"
on public.orders for insert to authenticated
with check (user_id = auth.uid());

create policy "Admins can update order status"
on public.orders for update to authenticated
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

create policy "Customers can read items from their own orders"
on public.order_items for select to authenticated
using (exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));

create policy "Customers can add items to their own orders"
on public.order_items for insert to authenticated
with check (exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));

create policy "Admins can manage order items"
on public.order_items for all to authenticated
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

-- Importante: asignar roles desde un proceso administrativo confiable.
-- No permitir que el usuario se autoasigne el rol admin.
