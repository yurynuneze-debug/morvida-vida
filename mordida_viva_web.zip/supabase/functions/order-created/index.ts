// Edge Function de ejemplo: validar una solicitud de pedido antes de persistirla.
// En producción, verifica el JWT, recalcula precios desde products y limita abuso.
// No acepta datos de tarjeta; integrar un proveedor de pagos por separado si aplica.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders() });
  }

  // Responder pronto a webhooks/eventos para no bloquear al emisor.
  // Este endpoint de ejemplo no procesa cobros ni guarda pedidos.
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Método no permitido" }), {
      status: 405, headers: { ...corsHeaders(), "Content-Type": "application/json" }
    });
  }

  return new Response(JSON.stringify({
    ok: true,
    mode: "demo",
    message: "Solicitud recibida. Conecta validación y persistencia antes de producción."
  }), { status: 200, headers: { ...corsHeaders(), "Content-Type": "application/json" } });
});

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
}
