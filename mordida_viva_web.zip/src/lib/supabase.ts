import { createClient } from "@supabase/supabase-js";

// La tienda funciona en modo demostración sin credenciales.
// Para conectar Supabase, define VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY
// en el entorno de desarrollo (sin publicar claves privadas).
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const supabase = supabaseUrl && supabaseAnonKey
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;
