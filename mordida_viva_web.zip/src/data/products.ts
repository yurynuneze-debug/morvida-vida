import type { Product } from "../types";

export const products: Product[] = [
  {
    id: "fruti-pop", name: "Fruti Pop", description: "Fruta deshidratada, dulce sin complicaciones.",
    price: 8500, category: "Fruta", emoji: "🍓", color: "pink", tag: "Favorito",
    ingredients: "Fresa, banano y manzana deshidratados."
  },
  {
    id: "mix-trail", name: "Mix Aventurero", description: "Una mezcla para seguir con toda la energía.",
    price: 11000, category: "Energía", emoji: "🥜", color: "yellow", tag: "Más energía",
    ingredients: "Maní, almendras, semillas de calabaza y uvas pasas."
  },
  {
    id: "crunch-garbanzo", name: "Garbanzo Crunch", description: "Crujiente, sabroso y listo para compartir.",
    price: 7500, category: "Crujientes", emoji: "🧆", color: "green",
    ingredients: "Garbanzos horneados, paprika suave y aceite de oliva."
  },
  {
    id: "coco-bites", name: "Coco Bites", description: "Bocados tropicales para una pausa feliz.",
    price: 9000, category: "Fruta", emoji: "🥥", color: "lavender",
    ingredients: "Coco, avena y dátiles."
  },
  {
    id: "avena-choco", name: "Avena Choco", description: "Un toque de chocolate para recargar el día.",
    price: 6500, category: "Energía", emoji: "🍫", color: "peach",
    ingredients: "Avena, cacao, banano y semillas de chía."
  },
  {
    id: "chips-platano", name: "Platanitos al Horno", description: "El crunch de siempre, en una versión más ligera.",
    price: 7000, category: "Crujientes", emoji: "🍌", color: "mint",
    ingredients: "Plátano verde, aceite de oliva y una pizca de sal."
  }
];
