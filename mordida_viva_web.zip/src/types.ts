export type ProductCategory = "Todos" | "Fruta" | "Crujientes" | "Energía";

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Exclude<ProductCategory, "Todos">;
  emoji: string;
  color: string;
  tag?: string;
  ingredients: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface CustomerOrder {
  id: string;
  customer: string;
  email: string;
  address: string;
  items: CartItem[];
  total: number;
  status: "Recibido" | "En preparación" | "En camino" | "Entregado";
  createdAt: string;
}
