import { useMemo, useState } from "react";
import { Link, NavLink, Route, Routes, useNavigate } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDown, ArrowRight, Check, Heart, Leaf, Menu, Minus, Plus,
  ShoppingBag, Sparkles, Sprout, Trash2, Truck, X, PackageCheck, ClipboardList
} from "lucide-react";
import { Toaster, toast } from "sonner";
import { products } from "./data/products";
import type { CartItem, CustomerOrder, Product, ProductCategory } from "./types";

const money = (value: number) => new Intl.NumberFormat("es-CO", {
  style: "currency", currency: "COP", maximumFractionDigits: 0
}).format(value);

const orderStorageKey = "mordida-viva-orders";
const cartStorageKey = "mordida-viva-cart";

function loadOrders(): CustomerOrder[] {
  try { return JSON.parse(localStorage.getItem(orderStorageKey) || "[]") as CustomerOrder[]; }
  catch { return []; }
}
function saveOrders(orders: CustomerOrder[]) {
  localStorage.setItem(orderStorageKey, JSON.stringify(orders));
}
function loadCart(): CartItem[] {
  try { return JSON.parse(localStorage.getItem(cartStorageKey) || "[]") as CartItem[]; }
  catch { return []; }
}

function App() {
  const [cart, setCart] = useState<CartItem[]>(loadCart);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const updateCart = (next: CartItem[]) => {
    setCart(next);
    localStorage.setItem(cartStorageKey, JSON.stringify(next));
  };
  const addToCart = (product: Product) => {
    const found = cart.find((item) => item.product.id === product.id);
    updateCart(found
      ? cart.map((item) => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
      : [...cart, { product, quantity: 1 }]);
    toast.success(`${product.name} se agregó a tu bolsa`);
  };
  const changeQuantity = (id: string, delta: number) => {
    updateCart(cart.map((item) => item.product.id === id
      ? { ...item, quantity: item.quantity + delta } : item).filter((item) => item.quantity > 0));
  };
  const removeItem = (id: string) => {
    updateCart(cart.filter((item) => item.product.id !== id));
    toast.info("Producto retirado de la bolsa");
  };
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const placeOrder = (customer: Omit<CustomerOrder, "id" | "items" | "total" | "status" | "createdAt">) => {
    if (!cart.length) return;
    const order: CustomerOrder = {
      ...customer,
      id: `MV-${Math.floor(10000 + Math.random() * 89999)}`,
      items: cart,
      total,
      status: "Recibido",
      createdAt: new Date().toISOString()
    };
    const orders = loadOrders();
    saveOrders([order, ...orders]);
    updateCart([]);
    toast.success("¡Pedido recibido! Ya puedes consultar su estado.");
    navigate("/pedidos");
  };

  return (
    <div className="min-h-screen bg-background text-ink">
      <Toaster position="top-center" richColors />
      <div className="announcement">
        <span>Pequeños antojos, grandes momentos</span><span className="announcement-dot">✳</span>
        <span>Envío gratis desde $60.000 en Bogotá</span>
      </div>
      <header className="site-header">
        <Link to="/" className="brand" aria-label="Mordida Viva, inicio">
          <span className="brand-mark"><Sprout size={24} strokeWidth={2.5} /></span>
          <span className="brand-copy">mordida<span>viva</span><small>SNACKS FELICES</small></span>
        </Link>
        <nav className={`desktop-nav ${mobileOpen ? "nav-open" : ""}`}>
          <NavLink to="/" onClick={() => setMobileOpen(false)}>Inicio</NavLink>
          <NavLink to="/productos" onClick={() => setMobileOpen(false)}>Nuestros snacks</NavLink>
          <a href="/#nosotros" onClick={() => setMobileOpen(false)}>Nuestra idea</a>
          <NavLink to="/pedidos" onClick={() => setMobileOpen(false)}>Mis pedidos</NavLink>
        </nav>
        <div className="header-actions">
          <Link to="/carrito" className="bag-button" aria-label={`Bolsa de compra, ${totalItems} productos`}>
            <ShoppingBag size={19} /><span>Mi bolsa</span><b>{totalItems}</b>
          </Link>
          <button className="mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Abrir menú">
            {mobileOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      <Routes>
        <Route path="/" element={<Home addToCart={addToCart} />} />
        <Route path="/productos" element={<ProductsPage addToCart={addToCart} />} />
        <Route path="/carrito" element={<CartPage cart={cart} total={total} changeQuantity={changeQuantity} removeItem={removeItem} onCheckout={() => navigate("/finalizar")} />} />
        <Route path="/finalizar" element={<CheckoutPage cart={cart} total={total} onSubmit={placeOrder} />} />
        <Route path="/pedidos" element={<OrdersPage />} />
        <Route path="*" element={<NotFound />} />
      </Routes>

      <Footer />
    </div>
  );
}

function Home({ addToCart }: { addToCart: (product: Product) => void }) {
  const { data: featured } = useQuery({
    queryKey: ["featured-products"],
    queryFn: async () => products.filter((product) => ["fruti-pop", "mix-trail", "crunch-garbanzo"].includes(product.id)),
    initialData: products.slice(0, 3)
  });
  return <>
    <main>
      <section className="hero section-wrap">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={15} /> SNACKS CON BUENA ONDA</div>
          <h1>Tu día merece<br />una <span>mordida</span><br /><span className="underline-word">feliz.</span></h1>
          <p>Snacks ricos, prácticos y hechos con ingredientes que conoces. Para tus pausas, tus planes y todo lo que te mueve.</p>
          <div className="hero-actions">
            <Link to="/productos" className="button button-primary">Encuentra tu snack <ArrowRight size={18} /></Link>
            <a className="text-link" href="#favoritos">Ver favoritos <ArrowDown size={16} /></a>
          </div>
          <div className="hero-proof">
            <div className="proof-icons"><span>🍓</span><span>🥜</span><span>🍌</span></div>
            <div><strong>Ingredientes sencillos</strong><small>Mucho sabor, cero drama.</small></div>
          </div>
        </div>
        <div className="hero-art">
          <div className="hero-sun"></div>
          <div className="hero-sticker sticker-one">¡ÑAM!</div>
          <div className="hero-sticker sticker-two"><Heart size={19} fill="currentColor" /> hecho con cariño</div>
          <div className="hero-bowl">
            <div className="bowl-fruit fruit-a">🍓</div><div className="bowl-fruit fruit-b">🥜</div>
            <div className="bowl-fruit fruit-c">🍌</div><div className="bowl-fruit fruit-d">🥥</div>
            <div className="bowl-fruit fruit-e">🍫</div>
            <div className="bowl-label">snack<br />happy!</div>
          </div>
          <div className="hero-spark spark-a">✳</div><div className="hero-spark spark-b">✦</div>
          <div className="hero-note">rico por naturaleza <Leaf size={16} /></div>
        </div>
      </section>

      <section className="benefits section-wrap">
        <div className="benefit"><span className="benefit-icon coral"><Leaf /></span><div><strong>Ingredientes reales</strong><p>Sabores simples que reconoces.</p></div></div>
        <div className="benefit"><span className="benefit-icon lime"><Heart /></span><div><strong>Antojos sin enredos</strong><p>Una pausa rica para tu rutina.</p></div></div>
        <div className="benefit"><span className="benefit-icon lilac"><Truck /></span><div><strong>Directo a tu puerta</strong><p>Compra fácil y recibe en casa.</p></div></div>
      </section>

      <section className="favorites section-wrap" id="favoritos">
        <div className="section-heading">
          <div><div className="eyebrow">LOS MÁS QUERIDOS</div><h2>Pequeños snacks,<br /><span>grandes favoritos.</span></h2></div>
          <Link to="/productos" className="text-link">Ver todos los snacks <ArrowRight size={17} /></Link>
        </div>
        <div className="product-grid">
          {featured.map((product, index) => <ProductCard key={product.id} product={product} index={index} addToCart={addToCart} />)}
        </div>
      </section>

      <section className="manifesto section-wrap" id="nosotros">
        <div className="manifesto-art"><div className="manifesto-orbit">✳</div><div className="manifesto-emoji">🍊</div><span className="manifesto-word">¡Qué rico<br />sentirse bien!</span></div>
        <div className="manifesto-copy"><div className="eyebrow"><Sprout size={15} /> NUESTRA FILOSOFÍA</div><h2>Comer rico también<br />puede <span>sentirse bien.</span></h2><p>Creemos que cuidarte no tiene que ser complicado. Por eso creamos snacks llenos de sabor, ideales para llevar en la mochila, tener en el escritorio o compartir con quien quieras.</p><Link to="/productos" className="button button-dark">Conoce los snacks <ArrowRight size={17} /></Link></div>
      </section>

      <section className="bottom-cta section-wrap">
        <div><span className="cta-kicker">TU PRÓXIMA PAUSA FAVORITA</span><h2>¿Se te antojó algo rico?</h2><p>Arma tu selección y dale un giro feliz a tu día.</p></div>
        <Link to="/productos" className="button button-light">Elegir mis snacks <ArrowRight size={18} /></Link>
        <span className="cta-doodle">✳</span>
      </section>
    </main>
  </>;
}

function ProductCard({ product, index, addToCart }: { product: Product; index: number; addToCart: (product: Product) => void }) {
  return <motion.article className={`product-card ${product.color}`} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * .07 }}>
    <div className="product-visual">
      {product.tag && <span className="product-tag">{product.tag}</span>}
      <span className="product-emoji" role="img" aria-label={product.name}>{product.emoji}</span>
      <span className="product-sunburst">✳</span>
      <span className="product-weight">Bolsa · 80 g</span>
    </div>
    <div className="product-info"><div><h3>{product.name}</h3><p>{product.description}</p></div>
      <div className="product-buy"><strong>{money(product.price)}</strong><button onClick={() => addToCart(product)} aria-label={`Agregar ${product.name}`}><Plus size={19} /></button></div>
    </div>
  </motion.article>;
}

function ProductsPage({ addToCart }: { addToCart: (product: Product) => void }) {
  const [category, setCategory] = useState<ProductCategory>("Todos");
  const [search, setSearch] = useState("");
  const categories: ProductCategory[] = ["Todos", "Fruta", "Crujientes", "Energía"];
  const visible = useMemo(() => products.filter((p) => (category === "Todos" || p.category === category)
    && `${p.name} ${p.description} ${p.ingredients}`.toLowerCase().includes(search.toLowerCase())), [category, search]);
  return <main className="inner-page section-wrap">
    <div className="page-intro"><div className="eyebrow">LA TIENDA FELIZ</div><h1>Encuentra tu <span>snack ideal.</span></h1><p>Algo frutal, algo crujiente o un poquito de energía. ¿Qué se te antoja hoy?</p></div>
    <div className="shop-tools"><div className="category-tabs">{categories.map((cat) => <button key={cat} className={category === cat ? "active" : ""} onClick={() => setCategory(cat)}>{cat}</button>)}</div><input className="search-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar un snack..." aria-label="Buscar snacks" /></div>
    {visible.length ? <div className="product-grid shop-grid">{visible.map((p, i) => <ProductCard key={p.id} product={p} index={i} addToCart={addToCart} />)}</div> : <div className="empty-state"><span>🍃</span><h2>No encontramos ese snack</h2><p>Prueba otra palabra o cambia la categoría.</p><button className="button button-primary" onClick={() => { setSearch(""); setCategory("Todos"); }}>Ver todos los snacks</button></div>}
  </main>;
}

function CartPage({ cart, total, changeQuantity, removeItem, onCheckout }: { cart: CartItem[]; total: number; changeQuantity: (id: string, delta: number) => void; removeItem: (id: string) => void; onCheckout: () => void }) {
  return <main className="inner-page section-wrap">
    <div className="page-intro compact"><div className="eyebrow">TU SELECCIÓN</div><h1>Tu bolsa <span>feliz.</span></h1><p>Revisa tus snacks antes de continuar.</p></div>
    {!cart.length ? <div className="empty-state"><span>🛍️</span><h2>Tu bolsa está esperando snacks</h2><p>Agrega tus favoritos y aquí aparecerán.</p><Link to="/productos" className="button button-primary">Explorar snacks <ArrowRight size={17} /></Link></div> :
      <div className="cart-layout"><div className="cart-items">{cart.map(({ product, quantity }) => <div className="cart-item" key={product.id}><div className={`cart-product-icon ${product.color}`}>{product.emoji}</div><div className="cart-product-copy"><h3>{product.name}</h3><p>{product.description}</p><strong>{money(product.price)}</strong></div><div className="quantity-control"><button onClick={() => changeQuantity(product.id, -1)} aria-label="Reducir cantidad"><Minus size={14} /></button><span>{quantity}</span><button onClick={() => changeQuantity(product.id, 1)} aria-label="Aumentar cantidad"><Plus size={14} /></button></div><button className="remove-button" onClick={() => removeItem(product.id)} aria-label={`Eliminar ${product.name}`}><Trash2 size={17} /></button></div>)}</div>
      <aside className="order-summary"><h2>Resumen de compra</h2><div className="summary-row"><span>Productos</span><strong>{money(total)}</strong></div><div className="summary-row"><span>Envío</span><strong>{total >= 60000 ? "Gratis" : "$6.000"}</strong></div><div className="summary-divider"></div><div className="summary-row total"><span>Total estimado</span><strong>{money(total + (total >= 60000 ? 0 : 6000))}</strong></div><p className="shipping-note"><Truck size={16} /> {total >= 60000 ? "¡Tu envío es gratis!" : `Te faltan ${money(60000 - total)} para tener envío gratis en Bogotá.`}</p><button className="button button-primary full-width" onClick={onCheckout}>Continuar con mis datos <ArrowRight size={17} /></button><Link to="/productos" className="continue-shopping">Seguir explorando</Link></aside></div>}
  </main>;
}

function CheckoutPage({ cart, total, onSubmit }: { cart: CartItem[]; total: number; onSubmit: (customer: Omit<CustomerOrder, "id" | "items" | "total" | "status" | "createdAt">) => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("Bogotá");
  const [notes, setNotes] = useState("");
  const shipping = total >= 60000 ? 0 : 6000;
  if (!cart.length) return <main className="inner-page section-wrap"><div className="empty-state"><span>🧺</span><h2>Primero llena tu bolsa</h2><p>Elige tus snacks favoritos para continuar.</p><Link to="/productos" className="button button-primary">Ir a la tienda</Link></div></main>;
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.includes("@") || !address.trim()) {
      toast.error("Completa tu nombre, un correo válido y la dirección de entrega.");
      return;
    }
    onSubmit({ customer: name.trim(), email: email.trim(), address: `${address.trim()}, ${city}${notes.trim() ? ` · Indicaciones: ${notes.trim()}` : ""}` });
  };
  return <main className="inner-page section-wrap">
    <div className="page-intro compact"><div className="eyebrow">ÚLTIMO PASO</div><h1>¿Dónde te <span>lo llevamos?</span></h1><p>Déjanos los datos para registrar tu pedido de demostración.</p></div>
    <div className="checkout-layout"><form className="checkout-form" onSubmit={submit}><h2>Datos de entrega</h2><label>Nombre completo<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej. Camila Rodríguez" required /></label><label>Correo electrónico<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="camila@correo.com" required /></label><label>Dirección de entrega<input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Calle, carrera, número..." required /></label><label>Ciudad<select value={city} onChange={(e) => setCity(e.target.value)}><option>Bogotá</option><option>Soacha</option><option>Chía</option><option>Otra ciudad</option></select></label><label>Indicaciones adicionales <span className="optional">(opcional)</span><textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Apartamento, portería, horario..." rows={3} /></label><div className="demo-disclaimer">Esta es una demostración: no se realiza ningún cobro ni envío real.</div><button className="button button-primary full-width" type="submit">Confirmar pedido de prueba <Check size={18} /></button></form>
      <aside className="order-summary"><h2>Tu pedido</h2>{cart.map((item) => <div className="checkout-line" key={item.product.id}><span>{item.product.emoji} {item.product.name} × {item.quantity}</span><strong>{money(item.product.price * item.quantity)}</strong></div>)}<div className="summary-divider"></div><div className="summary-row"><span>Envío</span><strong>{shipping ? money(shipping) : "Gratis"}</strong></div><div className="summary-row total"><span>Total</span><strong>{money(total + shipping)}</strong></div></aside></div>
  </main>;
}

function OrdersPage() {
  const { data: orders, isLoading } = useQuery({ queryKey: ["orders"], queryFn: async () => loadOrders() });
  return <main className="inner-page section-wrap">
    <div className="page-intro compact"><div className="eyebrow">TODO EN ORDEN</div><h1>Mis <span>pedidos.</span></h1><p>Consulta los pedidos registrados desde este navegador.</p></div>
    {isLoading ? <div className="loading-card"><div className="skeleton"></div><div className="skeleton"></div><div className="skeleton"></div></div> :
      !orders?.length ? <div className="empty-state"><span>📦</span><h2>Aún no tienes pedidos</h2><p>Cuando confirmes una compra de prueba, podrás verla aquí.</p><Link to="/productos" className="button button-primary">Elegir snacks <ArrowRight size={17} /></Link></div> :
      <div className="orders-list">{orders.map((order) => <article className="order-card" key={order.id}><div className="order-top"><div><span className="order-label">PEDIDO {order.id}</span><h2>{order.customer}</h2><p>{new Date(order.createdAt).toLocaleString("es-CO", { dateStyle: "medium", timeStyle: "short" })}</p></div><span className="status-pill"><PackageCheck size={15} /> {order.status}</span></div><div className="order-products">{order.items.map((item) => <span key={item.product.id}>{item.product.emoji} {item.product.name} × {item.quantity}</span>)}</div><div className="order-bottom"><span><ClipboardList size={16} /> Entrega: {order.address}</span><strong>{money(order.total + (order.total >= 60000 ? 0 : 6000))}</strong></div><p className="demo-disclaimer">Pedido de demostración · No se ha realizado un pago real.</p></article>)}</div>}
  </main>;
}

function NotFound() {
  return <main className="inner-page section-wrap"><div className="empty-state"><span>🌈</span><h2>Esta página se fue de snack break</h2><p>Volvamos a algo rico.</p><Link to="/" className="button button-primary">Volver al inicio</Link></div></main>;
}

function Footer() {
  return <footer className="footer"><div className="footer-main section-wrap"><Link to="/" className="brand footer-brand"><span className="brand-mark"><Sprout size={23} /></span><span className="brand-copy">mordida<span>viva</span><small>SNACKS FELICES</small></span></Link><p>Pequeñas pausas, grandes sonrisas.<br />Snacks para acompañar tu día.</p><div className="footer-links"><Link to="/productos">Tienda</Link><Link to="/pedidos">Mis pedidos</Link><a href="/#nosotros">Nuestra idea</a></div></div><div className="footer-bottom section-wrap"><span>© 2026 Mordida Viva · Proyecto demostrativo</span><span>Hecho con ingredientes de buena onda <Heart size={13} fill="currentColor" /></span></div></footer>;
}

export default App;
